<section class="footer-widget-wrapper">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6 col-sm-12">
                                <div class="footer-widget">
                                    <p class="subcsribe-text wow fadeInDown">No olvides seguirnos en nuestras redes sociales.</p>
                                    <div class="social-link wow fadeInDown">
                                        <ul>
                                            <li><a target="_blank" href="https://www.facebook.com/dteecuador/"><i class="fa fa-facebook"></i></a></li>
                                            <li><a target="_blank" href="https://twitter.com/DTE66707447"><i class="fa fa-twitter"></i></a></li>
                                            <li><a target="_blank" href="https://www.instagram.com/d_t_ecuador/"><i style="background-color: #dd268f" class="fa fa-instagram"></i></a></li>
                                            <li><a target="_blank" href="https://plus.google.com/u/1/116345474362418027838"><i class="fa fa-google-plus"></i></a></li>
                                            <li><a target="_blank" href="https://www.youtube.com/channel/UCBrXpOZHzY96pJ7OOiSOpxg?view_as=subscriber"><i class="fa fa-youtube"></i></a></li>
                                            
                                    </div>
                                </div><!-- /.footer-widget -->
                            </div><!-- /.col-md-6 -->
                            
                            <div class="col-md-3 col-sm-4 col-xs-4">
                                <div class="footer-widget">
                                    <h3 class="wow fadeInDown">Demos</h3>
                                    <ul class="wow fadeInDown">
                                        <li><a href="https://www.fitness.dtmowed.org" target="_blanck">FITNESS Sistema Gym</a></li>
                                        <li><a href="https://www.sisevents.dtmowed.org" target="_blanck">SIS EVENTS Gestión Eventos</a></li>
                                        <li><a href="https://www.srh.dtmowed.org" target="_blanck">SRH Registro Personal</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-4 col-xs-4">
                                <div class="footer-widget">
                                    <h3 class="wow fadeInDown"> </br> </h3>
                                    <ul class="wow fadeInDown">
                                        <li><a href="http://filetracking.dte-ecuador.org" target="_blanck">FILE TRACKING Digitalización de Archivos </a></li>
                                        {{--<li><a href="http://rueda.francomamani.com/#/auth" target="_blanck">RUEDA DE NEGOCIOS</a></li>--}}
                                        <li><a href="http://demo.coatlfact.com" target="_blanck">COATL FACT Facturacion Electronica</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div><!-- /.row -->
                    </div><!-- /.container -->
                </section>


                <footer class="footer-wrapper">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="copyright wow fadeInDown">
                                    <p>Copyright ©2019 DTE All Rights Reserved. Designed by <a href="https://www.dtmowed.org">DT MOWED</a> </p>
                                </div><!-- /.copyright -->
                            </div><!-- /.col-md-12 -->
                        </div><!-- /.row -->
                    </div><!-- /.container -->
                </footer>