<!-- Preloader -->
<div id="preloader">
			<div id="status">
				<div class="status-mes"></div>
			</div>
		</div>


	    <!-- jQuery -->
	    <script src="estilos/js/jquery.js"></script>
	    <!-- Bootstrap Core JavaScript -->
	    <script src="estilos/js/bootstrap.min.js"></script>
	    <!-- wow.min.js -->
	    <script src="estilos/js/wow.min.js"></script>
		<!-- jQuery REVOLUTION Slider  -->
	    <!-- owl-carousel -->
	    <script src="estilos/owl-carousel/owl.carousel.min.js"></script>
	    <!-- smoothscroll -->
	    <script src="estilos/js/smoothscroll.js"></script>
		<!-- Offcanvas Menu -->
		<script src="estilos/js/hippo-offcanvas.js"></script>
		<!-- easypiechart -->
		<script src="estilos/js/jquery.easypiechart.min.js"></script>
	    <!-- Scrolling Nav JavaScript -->
	    <script src="estilos/js/jquery.easing.min.js"></script>
		<!-- Magnific-popup -->
		<script src="estilos/js/jquery.magnific-popup.min.js"></script>
		<!-- Shuffle.min js -->
		<script src="estilos/js/jquery.shuffle.min.js"></script>
	    <!-- Custom Script -->
	    <script src="estilos/js/scripts.js"></script>
		<!-- Mi carrusel -->
	    <script src="estilos/js/carruselP.js"></script>