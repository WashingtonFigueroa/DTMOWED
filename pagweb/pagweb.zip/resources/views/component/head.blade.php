<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="shortcut icon" type="image/x-icon" href="estilos/img/logo.ico" />

    <title>DT MOWED</title>
    <!-- Web Fonts -->
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,900,700,500,300' rel='stylesheet' type='text/css'>
    <!-- Flaticon CSS -->
    <link href="estilos/fonts/flaticon/flaticon.css" rel="stylesheet">
    <!-- font-awesome CSS -->
    <link href="estilos/css/font-awesome.min.css" rel="stylesheet">
    <!-- owl.carousel CSS -->
    <link href="estilos/owl-carousel/owl.carousel.css" rel="stylesheet">
    <link href="estilos/owl-carousel/owl.theme.css" rel="stylesheet">
    <!-- Offcanvas CSS -->
    <link href="estilos/css/hippo-off-canvas.css" rel="stylesheet">
    <!-- animate CSS -->
    <link href="estilos/css/animate.css" rel="stylesheet">
    <!-- magnific-popup -->
    <link href="estilos/css/magnific-popup.css" rel="stylesheet">
	<!-- REVOLUTION BANNER CSS SETTINGS -->
    <!-- Bootstrap Core CSS -->
    <link href="estilos/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="estilos/css/style.css" rel="stylesheet">
    <!-- Responsive CSS -->
    <link href="estilos/css/responsive.css" rel="stylesheet">

    <script src="estilos/js/vendor/modernizr-2.8.1.min.js"></script>
    <!-- HTML5 Shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
	    <script src="estilos/js/vendor/html5shim.js"></script>
	    <script src="estilos/js/vendor/respond.min.js"></script>
    <![endif]-->
	</head>