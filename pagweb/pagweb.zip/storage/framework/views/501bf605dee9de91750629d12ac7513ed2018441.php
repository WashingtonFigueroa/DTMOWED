<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<p><strong>Nombre:</strong><?php echo $name; ?></p>
<p><strong>Correo:</strong><?php echo $email; ?></p>
<p><strong>Mensaje:</strong><?php echo $mensajee; ?></p>

</body>
</html>